import { main } from './complete-seed';

// Run the main seeding function
main();
