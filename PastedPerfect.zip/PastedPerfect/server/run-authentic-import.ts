import { main } from './import-authentic-data';

main();
