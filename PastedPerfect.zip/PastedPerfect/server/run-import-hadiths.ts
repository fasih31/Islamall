import { main } from './import-hadiths';

main();
