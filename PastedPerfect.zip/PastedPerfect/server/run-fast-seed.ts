import { main } from './fast-seed';

main();
